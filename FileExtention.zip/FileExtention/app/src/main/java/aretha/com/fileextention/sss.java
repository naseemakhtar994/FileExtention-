package aretha.com.fileextention;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import java.io.File;

/**
 * Created by naseem on 11/10/17.
 */

public class sss extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        File file = null;
        String paht = file.getAbsolutePath() + ".jpeg";
    }
}
