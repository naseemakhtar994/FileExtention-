package aretha.com.fileextention

import android.app.Activity
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import aretha.com.ZipManager

import kotlinx.android.synthetic.main.activity_main.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.channels.FileChannel
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    companion object {
        var directory=""
        var extention=""
        var files1 = ArrayList<File>()
        var s = arrayOfNulls<String>(1000)
        lateinit var _Activity:Activity

        fun listf(directoryName: String, files: ArrayList<File>):ArrayList<File> {
            val directory = File(directoryName)
            var filerename:File;
            // get all the files from a directory
            val fList = directory.listFiles()
            for (file in fList!!) {
                if (file.isFile) {

                    if (getFileExtension(file).equals("")) {


                        val paht = file.absolutePath + extention
                        filerename = File(paht)

                        file.renameTo(filerename)
                        files.add(file)

                    }


                } else if (file.isDirectory) {
                    listf(file.absolutePath, files)
                }
            }

            return files
        }

        @Throws(IOException::class)
        fun copyFile(sourceFile: File, destFile: File) {
            if (!destFile.parentFile.exists())
                destFile.parentFile.mkdirs()

            if (!destFile.exists()) {
                destFile.createNewFile()
            }

            var source: FileChannel? = null
            var destination: FileChannel? = null

            try {
                source = FileInputStream(sourceFile).channel
                destination = FileOutputStream(destFile).channel
                destination!!.transferFrom(source, 0, source!!.size())
            } finally {
                if (source != null) {
                    source.close()
                }
                if (destination != null) {
                    destination.close()
                }
            }
        }







// calling the zip function


        private fun getFileExtension(file: File): String {
            val fileName = file.name
            return if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
                fileName.substring(fileName.lastIndexOf(".") + 1)
            else
                ""
        }
    }

    public class  ConvetExtention : AsyncTask<Void, Void, ArrayList<File>>() {


        override fun doInBackground(vararg p0: Void?): ArrayList<File> {

           return listf(directory, files1)


        }

        private fun getFileExtension(file: File): String {
            val fileName = file.name
            return if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
                fileName.substring(fileName.lastIndexOf(".") + 1)
            else
                ""
        }

        var count=0;

        fun listf(directoryName: String, files: ArrayList<File>):ArrayList<File> {
            val directory = File(directoryName)
            var filerename:File;
            // get all the files from a directory
            val fList = directory.listFiles()
            for (file in fList!!) {
                if (file.isFile) {



                      /*  val paht = file.absolutePath + extention
                        filerename = File(paht)

                        file.renameTo(filerename)
                        files.add(file)*/

                    if (getFileExtension(file).equals("mp4")||getFileExtension(file).equals(".mp4")||getFileExtension(file).equals(".wav")||getFileExtension(file).equals("wav")||getFileExtension(file).equals("amr")||getFileExtension(file).equals(".amr")) {
                        copyFile(File(file.absolutePath), File(Environment.getExternalStorageDirectory().toString() + "/my/" + file.name))
                    }


                } else if (file.isDirectory) {
                    listf(file.absolutePath, files)
                }
            }

            return files
        }

        override fun onPostExecute(result: ArrayList<File>?) {
             super.onPostExecute(result)

            Toast.makeText(_Activity,"Done",Toast.LENGTH_LONG).show()

        }


    }



    public class  StoreAllImages : AsyncTask<Void, Void, ArrayList<File>>() {


        override fun doInBackground(vararg p0: Void?): ArrayList<File> {

            return listf(directory, files1)


        }

        private fun getFileExtension(file: File): String {
            val fileName = file.name
            return if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
                fileName.substring(fileName.lastIndexOf(".") + 1)
            else
                ""
        }

        var count=0;

        fun listf(directoryName: String, files: ArrayList<File>):ArrayList<File> {
            val directory = File(directoryName)

            // get all the files from a directory
            val fList = directory.listFiles()
            for (file in fList!!) {
                if (file.isFile) {

                   //- /storage/5244-5338/my/2114-growthcampaign074252-10142016a3867.png
                  //-  /storage/5244-5338/my/.androidlav/2114-growthcampaign074252-10142016a3867.png

                    var  filerename = File(Companion.directory +"/"+file.name)

                      file.renameTo(filerename)


                    /*   if (getFileExtension(file).equals("mp4")||getFileExtension(file).equals(".mp4")||getFileExtension(file).equals(".wav")||getFileExtension(file).equals("wav")||getFileExtension(file).equals("amr")||getFileExtension(file).equals(".amr")) {
                           copyFile(File(file.absolutePath), File(Environment.getExternalStorageDirectory().toString() + "/my/" + file.name))
                       }*/


                } else if (file.isDirectory) {
                    listf(file.absolutePath, files)
                }
            }

            return files
        }

        override fun onPostExecute(result: ArrayList<File>?) {
            super.onPostExecute(result)

            Toast.makeText(_Activity,"Done",Toast.LENGTH_LONG).show()

        }


    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        /*/storage/014F-4B76*/
        _Activity=this
        ZipManager().getExternalStorageDirectories(this);
        button.setOnClickListener {

            /*Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)*/
             directory = ZipManager().getExternalStorageDirectories(this)[0]+"/"
            extention=editText2.text.toString()

            ConvetExtention().execute();


        }


        button2.setOnClickListener {


            if (editText2.text.toString().equals("")) {
                directory = Environment.getExternalStorageDirectory().toString() + "/" + editText.text.toString()
            }else{
                directory= ZipManager().getExternalStorageDirectories(this)[0]+"/"+ editText2.text.toString()
            }
            StoreAllImages().execute()

        }

    }

    fun copyFileOrDirectory(srcDir: String, dstDir: String) {

        try {
            val src = File(srcDir)
            val dst = File(dstDir, src.name)

            if (src.isDirectory) {

                val files = src.list()
                val filesLength = files!!.size
                for (i in 0 until filesLength) {
                    val src1 = File(src, files[i]).path
                    val dst1 = dst.path
                    copyFileOrDirectory(src1, dst1)

                }
            } else {
                copyFile(src, dst)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    @Throws(IOException::class)
    fun copyFile(sourceFile: File, destFile: File) {
        if (!destFile.parentFile.exists())
            destFile.parentFile.mkdirs()

        if (!destFile.exists()) {
            destFile.createNewFile()
        }

        var source: FileChannel? = null
        var destination: FileChannel? = null

        try {
            source = FileInputStream(sourceFile).channel
            destination = FileOutputStream(destFile).channel
            destination!!.transferFrom(source, 0, source!!.size())
        } finally {
            if (source != null) {
                source.close()
            }
            if (destination != null) {
                destination.close()
            }
        }
    }


}
